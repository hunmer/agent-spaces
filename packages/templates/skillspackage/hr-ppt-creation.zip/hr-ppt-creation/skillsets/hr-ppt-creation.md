---
name: hr-ppt-creation
description: >-
  PPT 制作专家包。适用于PPT 制作、从PPT大纲与演示结构规划生成、PowerPoint文件全功能创建编辑（布局/ 模板/图表/备注）、
  麦肯锡风格专业顾问级演示文稿设计、到参考模板视觉风格提取与幻灯片重建、乔布斯风极简科技感HTML演示稿一键生成、
  python-pptx多布局多图文混排科技风PPT制作的完整PPT制作工作流等场景；
  也适用于用户明确要求调用「PPT 制作 / PPT 制作专家包 / PPT Creation」。
version: 1.0.0
metadata:
  author: SkillHub
  package_type: meta-skill
  display_name: PPT 制作
  aliases:
    - PPT 制作
    - PPT 制作专家包
    - PPT 制作技能包
    - PPT Creation
    - hr-ppt-creation
    - ppt-creation
orchestration:
  children:
    - cn-ppt-outline-writer
    - powerpoint-pptx
    - mck-ppt-design
    - ppt-from-template
    - ppt
    - dragon-ppt-maker
compatibility: SkillHub meta-skill, exportable to Claude Code / Codex markdown skill.
---
# PPT 制作工作流

你现在要完成一项 PPT 演示文稿的制作任务。你已安装以下 Skill，请按步骤串联使用：

## 步骤 1：PPT 大纲与结构规划（获取层）
使用 **CN PPT Outline Writer** 完成：
- 根据演示主题生成 PPT 大纲和页面结构
- 规划每页的核心信息和叙事逻辑
- 设计演示文稿的整体故事线
- 确定页数、章节划分和过渡方式
- 支持生成 HTML 演示文稿预览

输出 PPT 大纲和页面结构规划。

## 步骤 2：PowerPoint 文件全功能编辑（获取层）
使用 **Powerpoint / PPTX** 完成：
- 创建、检查和编辑 PPTX 文件
- 配置幻灯片布局、模板和占位符
- 添加演讲者备注和批注
- 插入图表、表格和数据可视化
- 执行视觉质检确保格式一致

输出基础 PPTX 文件和布局配置。

## 步骤 3：麦肯锡风格专业设计（分析层）
使用 **Mck Ppt Design Skill** 完成：
- 按麦肯锡咨询风格从零创建专业 PPT
- 应用顾问级排版规范和配色方案
- 设计数据驱动的图表和分析页面
- 确保每页有明确的 Takeaway 信息
- 输出高标准的商业演示文稿

输出麦肯锡风格专业 PPT。

## 步骤 4：模板风格提取与重建（分析层）
使用 **PPT from Template** 完成：
- 从参考模板中提取视觉风格（配色/字体/布局）
- 使用 PptxGenJS 从头重新创建幻灯片
- 保持品牌视觉一致性
- 适配不同场景的模板需求（汇报/路演/培训）
- 输出风格统一的演示文稿

输出基于模板风格重建的 PPT。

## 步骤 5：极简科技感演示稿生成（输出层）
使用 **ppt** 完成：
- 将讲稿一键生成乔布斯风极简科技感演示稿
- 输出单个可直接运行的 HTML 文件
- 支持竖屏和横屏两种模式
- 自动排版和视觉设计
- 适合科技产品发布、技术分享等场景

输出极简科技感 HTML 演示文件。

## 步骤 6：科技风多布局 PPT 制作（输出层）
使用 **PPT制作** 完成：
- 使用 python-pptx 制作科技风 PPT
- 支持多种幻灯片布局和图文混排
- 嵌入 HTML 内容和数据可视化
- 生成可编辑的 .pptx 文件
- 适合工作汇报、项目展示等正式场景

## 最终输出
将以上步骤的结果整合为完整的 PPT 制作包，交付以下文件：
1. **PPT 大纲**：页面结构、叙事逻辑、章节划分
2. **基础 PPTX 文件**：布局配置、图表表格、备注批注
3. **麦肯锡风格 PPT**：顾问级设计、数据图表、Takeaway
4. **模板风格 PPT**：品牌一致性、视觉提取、风格重建
5. **极简科技感演示**：乔布斯风格、HTML 文件、一键运行
6. **科技风 PPTX 文件**：多布局、图文混排、可编辑格式