# Phaser.js 游戏开发工作流

你现在要完成一次 Phaser 4 游戏开发任务。按问题类型选用对应技能解决具体问题。

## 使用策略

Phaser 4 是组件化的现代游戏引擎，按问题类型选用对应技能：

- **game-setup-and-config**：游戏配置、Phaser.Game 实例创建
- **scenes**：场景生命周期（preload/create/update）、Scene 类、场景切换
- **sprites-and-images**：Sprite/Image 创建、纹理
- **animations**：AnimationManager/AnimationState、spritesheet、动画事件
- **physics-arcade** / **physics-matter**：物理（速度/碰撞 / 复杂刚体）
- **input-keyboard-mouse-touch**：键盘/鼠标/触摸输入
- **cameras** / **particles** / **filters-and-postfx**：相机/粒子/PostFX 滤镜
- **tilemaps**：瓦片地图
- **v3-to-v4-migration** / **v4-new-features**：升级迁移

## 任务执行原则

1. 先定位问题域，调用对应技能
2. 遵循 Phaser 4 惯用法（组件化、TypeScript、事件驱动）
3. 场景结构清晰：preload 加载 → create 构建 → update 帧循环
4. 性能优先：对象池、批量渲染、避免每帧 new
